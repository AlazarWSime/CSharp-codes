﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormApp.Session
{
    internal class UserSession
    {
        public static Guid? LoggedInUserID { get; set; }
        public static string LoggedInUsername { get; set; }
        public static string LoggedInRoleName { get; set; }
        public static Guid? LoggedInRoleID { get; set; }

        public static bool IsLoggedIn => LoggedInUserID.HasValue;

        // Clear session when logging out
        public static void ClearSession()
        {
            LoggedInUserID = null;
            LoggedInUsername = null;
            LoggedInRoleName = null;
            LoggedInRoleID = null;
        }
    }
}
